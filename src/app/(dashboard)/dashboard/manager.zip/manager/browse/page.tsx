'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { UserProfile } from '@/types'; // Use the main UserProfile type
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FaSearch, FaSpinner } from 'react-icons/fa';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import toast from 'react-hot-toast';
import Loader from '@/components/ui/loader';

// --- IMPORTANT ---
// You already have a talent card in your main dashboard page.
// You should EXTRACT that into its own component file, e.g.:
// src/components/TalentCard.tsx
//
// For now, I'll create a simple placeholder here.
// You should replace this with your real <TalentCard /> component.
const TalentCardPlaceholder = ({ user }: { user: UserProfile }) => (
  <Card className="bg-slate-800 border-slate-700 text-white">
    <CardContent className="p-4">
      <h3 className="font-bold">{user.fullName}</h3>
      <p className="text-sm text-blue-400">{user.primarySkill || 'Skill not listed'}</p>
      <p className="text-xs text-slate-400 mt-2 truncate">{user.bio}</p>
      <Button asChild variant="outline" size="sm" className="mt-4">
        <Link href={`/profile/${user.uid}`}>View Profile</Link>
      </Button>
    </CardContent>
  </Card>
);


export default function BrowseTalentPage() {
  const { userProfile, loading: authLoading } = useAuth();
  const [talent, setTalent] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [skillFilter, setSkillFilter] = useState('all');

  // TODO: Populate this from your skills list
  const SKILLS_LIST = [
    'Full-Stack Development',
    'UI/UX Design',
    'Motion Graphics',
    'React',
    'Node.js',
    'Python',
  ];

  useEffect(() => {
    const fetchTalent = async () => {
      setLoading(true);
      try {
        // Base query
        let talentQuery;

        if (skillFilter !== 'all') {
          // Query by skill
          talentQuery = query(
            collection(db, 'users'),
            where('userType', '==', 'youth'),
            where('selectedSkills', 'array-contains', skillFilter),
            orderBy('createdAt', 'desc'),
            limit(20)
          );
        } else {
          // Get all talent
          talentQuery = query(
            collection(db, 'users'),
            where('userType', '==', 'youth'),
            orderBy('createdAt', 'desc'),
            limit(20)
          );
        }

        const querySnapshot = await getDocs(talentQuery);
        const talentList = querySnapshot.docs.map(doc => doc.data() as UserProfile);
        
        // Client-side search (if Firestore query is too basic)
        const filteredList = talentList.filter(user => 
          user.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          user.primarySkill?.toLowerCase().includes(searchTerm.toLowerCase())
        );

        setTalent(filteredList);

      } catch (error) {
        console.error("Error fetching talent:", error);
        toast.error('Failed to load talent.');
      }
      setLoading(false);
    };

    fetchTalent();
  }, [searchTerm, skillFilter]); // Refetch when filters change

  if (authLoading) return <Loader />;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Browse Talent</h1>
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search by name or primary skill..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={skillFilter} onValueChange={setSkillFilter}>
          <SelectTrigger className="w-full md:w-[240px]">
            <SelectValue placeholder="Filter by skill" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Skills</SelectItem>
            {SKILLS_LIST.map(skill => (
              <SelectItem key={skill} value={skill}>{skill}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-20">
          <FaSpinner className="h-10 w-10 animate-spin text-blue-500" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {talent.length > 0 ? (
            talent.map(user => (
              // --- REPLACE THIS with your <TalentCard> component ---
              <TalentCardPlaceholder key={user.uid} user={user} />
            ))
          ) : (
            <p className="text-slate-400 col-span-full text-center py-10">
              No talent found matching your criteria.
            </p>
          )}
        </div>
      )}
    </div>
  );
}